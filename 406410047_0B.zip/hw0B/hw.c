#define _GNU_SOURCE
#include <stdio.h>
#include <pthread.h>
#include <stdatomic.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <sched.h>
#include <stdio.h>
#include <string.h>
#include <sys/syscall.h> 
#include <assert.h>
#include <string.h>
#include <stdbool.h>
FILE *temp1, *temp2;
float printtemp()
{
	int eatret;
	int temparr[2];
	temp1 = fopen("/sys/class/hwmon/hwmon0/temp4_input", "r");
    	assert(temp1 != NULL);
    	temp2 = fopen("/sys/class/hwmon/hwmon0/temp4_input", "r");
    	assert(temp2 != NULL);
	for(int i = 0 ; i < 2; i++)
		temparr[i] = -1;
	fseek(temp1, 0, SEEK_SET);
    	eatret=fscanf(temp1, "%d", &temparr[0]);
    	fseek(temp2, 0, SEEK_SET);
    	eatret=fscanf(temp2, "%d", &temparr[1]);
	fclose(temp1);
	fclose(temp2);
	int tottmp = 0;
	for(int i= 0; i < 2; i++)
		tottmp+=temparr[i];
	float avgtemp = tottmp / 2;
	return avgtemp;

}
long timespec2nano(struct timespec ts)
{
	return ts.tv_sec * 1000000000 + ts.tv_nsec;
}
int main(int argc, char **argv)
{
	int tempture = 35;
	if(argc == 2)
		sscanf(argv[1], "%d",&tempture);
	fprintf(stderr, "target = %d\n", tempture);
	tempture = tempture * 1000;
	float temp;
	int try = 1;
	while((temp = printtemp()) > tempture)
	{
		fprintf(stderr, "#%02d sec %.2f ℃ \n",try,((float)temp)/1000);
		try++;
		sleep(1);
	}
	printf("temp %.2f℃ , \n",((float)temp)/1000);
}
